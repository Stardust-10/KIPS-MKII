/* USER CODE BEGIN Header */
/**
******************************************************************************
* @file           : main.c
* @brief          : Main program body
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the
* License. You may obtain a copy of the License at:
*                        opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "USB_PD_core.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

I2C_HandleTypeDef *hi2c[I2CBUS_MAX];
unsigned int Address;
unsigned int AddressSize = I2C_MEMADD_SIZE_8BIT;
USB_PD_I2C_PORT STUSB45DeviceConf[USBPORT_MAX];
uint32_t timer_cnt = 0;
int Flag_count = 0;
int PB_press=0;
int Time_elapse=1;
extern uint8_t Cut[USBPORT_MAX];
uint8_t USB_PD_Interupt_Flag[USBPORT_MAX] ;
uint8_t USB_PD_Interupt_PostponedFlag[USBPORT_MAX] ; 
uint8_t push_button_Action_Flag[USBPORT_MAX];
uint8_t Timer_Action_Flag[USBPORT_MAX];
uint8_t connection_flag[USBPORT_MAX]={1};
uint8_t HR_rcv_flag[USBPORT_MAX] = {0};
uint32_t VBUS_Current_limitation[USBPORT_MAX] = {5},Previous_VBUS_Current_limitation[USBPORT_MAX] ; 

/* PDO Variables */
extern USB_PD_StatusTypeDef PD_status[USBPORT_MAX] ;
extern USB_PD_SNK_PDO_TypeDef PDO_SNK[USBPORT_MAX][3];
extern USB_PD_SRC_PDOTypeDef PDO_FROM_SRC[USBPORT_MAX][7];
extern uint8_t PDO_FROM_SRC_Valid[USBPORT_MAX];
extern uint8_t PDO_FROM_SRC_Num_Sel[USBPORT_MAX];
extern uint8_t PDO_FROM_SRC_Num[USBPORT_MAX];
extern uint8_t Policy_Engine_State[USBPORT_MAX];
extern uint8_t Go_disable_once[USBPORT_MAX];
extern uint8_t Final_Nego_done[USBPORT_MAX] ;
extern uint8_t Core_Process_suspended ;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
int Device_Manager(uint8_t Usb_Port);
extern void nvm_flash(uint8_t Usb_Port);
//extern STUSB_GEN1S_ALERT_STATUS_MASK_RegTypeDef Alert_Mask;

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
* @brief  The application entry point.
* @retval int
*/
int main(void)
{
  /* USER CODE BEGIN 1 */
  
  int Usb_Port = 0;
  /* USER CODE END 1 */
  
  /* MCU Configuration--------------------------------------------------------*/
  
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  
  /* USER CODE BEGIN Init */
  
  /* USER CODE END Init */
  
  /* Configure the system clock */
  SystemClock_Config();
  
  /* USER CODE BEGIN SysInit */
  
  /* USER CODE END SysInit */
  
  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  // to enable Traces by UART enable this Preprocessor in Option/C/C++ compiler/Preprocessor 
#ifdef PRINTF_UART  
  MX_USART2_UART_Init();
#endif  
  /* USER CODE BEGIN 2 */
  hi2c[0]= &hi2c1;
  //  hi2c[1]= &hi2c2;
  STUSB45DeviceConf[Usb_Port].I2cBus = Usb_Port;
  STUSB45DeviceConf[Usb_Port].I2cDeviceID_7bit = 0x28;
  AddressSize = I2C_MEMADD_SIZE_8BIT; 
  USB_PD_Interupt_PostponedFlag[0]= 0; /* this flag is 1 if I2C is busy when Alert signal raise */
  USB_PD_Interupt_Flag[Usb_Port] = 1;
  Final_Nego_done[Usb_Port]=0;
  Go_disable_once[Usb_Port] = 0;
  
  memset((uint32_t *)PDO_FROM_SRC[Usb_Port], 0, 7);
  memset((uint32_t *)PDO_SNK[Usb_Port], 0, 3);
  
  usb_pd_init(Usb_Port);   // after this USBPD alert line must be high 
  
  
  push_button_Action_Flag[Usb_Port]=0;
  Read_RDO(Usb_Port);
  
  connection_flag[Usb_Port] =1;
  Previous_VBUS_Current_limitation[Usb_Port] = VBUS_Current_limitation[Usb_Port];
  
  HAL_GPIO_WritePin(Yelow_LED_GPIO_Port,Yelow_LED_Pin,GPIO_PIN_SET); // Yelow led is ON when CPU is running 
  HAL_GPIO_WritePin(Red_LED_GPIO_Port,Red_LED_Pin,GPIO_PIN_SET);// Red led is ON when port is connected 
  /* USER CODE END 2 */
  
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    
    /* USER CODE BEGIN 3 */
    
    if( push_button_Action_Flag[Usb_Port] == 1  )
      push_button_Action();  
    
    // bellow to enable the STUSB4500_PDO_rolling_DEMO Option/C/C++ compiler/Preprocessor TIMER_ACTION 
#ifdef TIMER_ACTION    
    if( Timer_Action_Flag[Usb_Port] == 1  )
      Timer_Action();          
#endif 
    
    Device_Manager(Usb_Port);
    
    if( Final_Nego_done[Usb_Port] == 1)
    {
      HAL_GPIO_WritePin(Yelow_LED_GPIO_Port,Yelow_LED_Pin,GPIO_PIN_RESET);
      Core_Process_suspended = 1;
      HAL_PWR_EnterSLEEPMode(NULL, PWR_SLEEPENTRY_WFI );
      //HAL_PWR_EnterSTOPMode(uint32_t Regulator, uint8_t STOPEntry) 
    }
  }
  /* USER CODE END 3 */
}

/**
* @brief System Clock Configuration
* @retval None
*/
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
    |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
* @brief  EXTI line detection callback.
* @param  GPIO_Pin Specifies the port pin connected to corresponding EXTI line.
* @retval None
*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  int Usb_Port = 0;
#ifndef TIMER_ACTION 
  HAL_ResumeTick();
#endif  
  Core_Process_suspended = 0 ;
  HAL_GPIO_WritePin(Yelow_LED_GPIO_Port,Yelow_LED_Pin,GPIO_PIN_SET);
  switch(GPIO_Pin)
  {
    
  case ( ALERT_A_Pin)://B1_Pin 
    { 
      
      
      if((hi2c[0])->Lock == HAL_UNLOCKED)   
      {                                    
        ALARM_MANAGEMENT(Usb_Port);
      }
      else 
      {
        USB_PD_Interupt_PostponedFlag[Usb_Port] = 1;
        USB_PD_Interupt_Flag[Usb_Port] = 1;          
      }     
    } 
    break;
    
    // SELECT HERE WHICH function must be attached to the BLUE push button
  case ( B1_Pin)://B1_Pin 
    { 
      push_button_Action_Flag[Usb_Port] = 1 ;
      Final_Nego_done[Usb_Port]=0;
      PB_press ++ ;
    } 
    break;
  }
}

int Device_Manager(uint8_t Usb_Port)
{
  int Status;
  
  Status = Get_Device_STATUS(Usb_Port);
  switch(Status)
  {
  case Not_Connected :
#ifdef PRINTF 
    printf("\r\n ---- Usb_Port #0: NOT CONNECTED  ---------------\r\n");
#endif       
    break;
  case TypeC_Only :
    Print_Type_C_Only_Status(Usb_Port);
    break;
  case Connected_Unknown_SRC_PDOs :
    {
    Send_Soft_reset_Message(Usb_Port);
    Final_Nego_done[Usb_Port] = 0;
    }
    break;
  case Connected_5V_PD :
#ifdef PRINTF 
    printf(" ---> Final PDO_Negociated 5V \r\n");
#endif                
    break;
  case Connected_no_Match_found :
#ifdef PRINTF
    printf(" ---> No Matching Found \r\n");
#endif
    break;
  case Connected_Matching_ongoing :
    {
    Send_Soft_reset_Message(Usb_Port);
    Final_Nego_done[Usb_Port] = 0;
    }   
#ifdef PRINTF 
    printf(" ---> Matching on going reset sent \r\n");
#endif                      
    break;
  case Connected_Mached :
#ifdef PRINTF 
    printf(" ---> Final PDO_Negociated \r\n");
#endif 
    break;
  case Not_Connected_attached_wait :
#ifdef PRINTF          
    printf("\r\n ---- Usb_Port #0: in Attached wait state -------\r\n");
    printf("\r\n ---- Usb_Port #0: reset by register ongoing  -------\r\n");
#endif       
    break;
  case Hard_Reset_ongoing :
#ifdef PRINTF            
    printf("----------HW reset ongoing ---------\r\n");
#endif  
    break;
  default: // Policy_Defauld 
    break;
  }
  if (VBUS_Current_limitation[Usb_Port] != Previous_VBUS_Current_limitation[Usb_Port])
  {
    Previous_VBUS_Current_limitation[Usb_Port] = VBUS_Current_limitation[Usb_Port];
#ifdef PRINTF 
    
    printf("\r\n - Current limit modified I bus set to %d mA ---\r\n",VBUS_Current_limitation[Usb_Port]);
#endif 
  } 
  return 0;
  
}

void push_button_Action(void)
{
  uint8_t Usb_Port = 0;
#ifdef PRINTF
  printf("Push button \r\n");
#endif
  /*update PDO num to 1 then Reset */
  switch (PB_press%5)  /* line for 4 state */
  {
  case 0:     /* Negotiation with all SOURCE PDO by increasing order */
    
    break ;
  case 1 :    /* set Number of PDO to 1 to force 5V */
    {
      //Send_DRSwap_Message(Usb_Port);
      Negotiate_5V(Usb_Port);       
      Send_Soft_reset_Message(Usb_Port);
    }
    break;
  case 2 :   /* Negotiate with the best SOURCE PDO between 14V and 20V as long as it is 15W or more*/
    {
      
      if (! Find_Matching_SRC_PDO(Usb_Port,15,14000,20000))
      {
        Send_Soft_reset_Message(Usb_Port);
      }
      Send_Soft_reset_Message(Usb_Port);
    }
    break;
  case 3 :   /* 5V, 9V, 12V, 15V and 20V rolling function will be called */
    {
      
    }            
    break;  
  case  4: 
    {
      HW_Reset_state(0);
      PB_press = 0 ;
      Time_elapse = 3;
    }
    break;
  default :
    
    break;
  }
  push_button_Action_Flag[Usb_Port] = 0 ;
}

void Timer_Action(void)
{
  int Usb_Port = 0;
  
  if (PB_press == 0 )      // bellow code will request succesfully the various SOURCE PDO by increasing order
  {
    if ((PDO_FROM_SRC_Valid[Usb_Port] == 1) && (PDO_FROM_SRC_Num[Usb_Port] > 1))
    {
       Request_SRC_PDO_NUMBER(Usb_Port, Time_elapse%PDO_FROM_SRC_Num_Sel[Usb_Port]+1);
      Send_Soft_reset_Message(Usb_Port);   
    }
    Time_elapse ++ ;        
  } 
  else  if(PB_press == 3 )  // bellow code will roll up and down the 5V, 9V, 12V, 15V and 20V PDOs
  {
#ifdef PRINTF    
    printf("\r\n--- Timer Action ---\r\n");	
#endif   
    
    switch(Time_elapse )
    {
    case 1 :
      { 
        /*update PDO num to 1 then Reset */
#ifdef PRINTF          
        printf(" STUSB45 Reset(1) \r\n");
#endif
        Update_PDO(Usb_Port,2,15000,500);
        Update_PDO(Usb_Port,3,20000,500); 
        Update_Valid_PDO_Number( Usb_Port , 3 );              
        if (Flag_count)
          Time_elapse ++ ;
        else 
          Time_elapse -- ;  
      } break;      
    case 2 :
      {
#ifdef PRINTF          
        printf(" STUSB45 Reset(2) \r\n");
#endif          /*update PDO num to 1 then Reset */
        
        Update_PDO(Usb_Port,2,15000,500);
        Update_PDO(Usb_Port,3,20000,500); 
        Update_Valid_PDO_Number( Usb_Port , 2 ); 
        
        if (Flag_count)
          Time_elapse ++ ;
        else 
          Time_elapse -- ;  
      } break;  
    case 3 :
      {
#ifdef PRINTF          
        printf(" STUSB45 Reset(3) \r\n");
#endif          /*update PDO num to 1 then Reset */
        
        Update_PDO(Usb_Port,2,  9000,500);
        Update_PDO(Usb_Port,3, 12000,500);             
        
        Update_Valid_PDO_Number( Usb_Port , 3 );
        if (Flag_count)
          Time_elapse ++ ;
        else 
          Time_elapse -- ;  
      } break;  
      
    case 4 :
      {
#ifdef PRINTF          
        printf(" STUSB45 Reset(4) \r\n");
#endif          /*update PDO num to 1 then Reset */
        
        Update_PDO(Usb_Port,2,  9000,500);
        Update_PDO(Usb_Port,3, 12000,500);             
        
        Update_Valid_PDO_Number( Usb_Port , 2 );
        
        if (Flag_count)
          Time_elapse ++ ;
        else 
          Time_elapse -- ;  
      } break;  
      
    case 5 :
      {
#ifdef PRINTF          
        printf(" STUSB45 Reset(5) \r\n");
#endif          /*update PDO num to 1 then Reset */
        
        Update_Valid_PDO_Number( Usb_Port , 1 );
        if (Flag_count)
          Time_elapse ++ ;
        else 
          Time_elapse -- ;  
      } break;  
      
    default :
      Time_elapse = 1;
      break;            
    }
    
    Send_Soft_reset_Message(Usb_Port);
    
    if ( Time_elapse == 1)
      Flag_count = 1 ;
    if ( Time_elapse == 5)
      Flag_count = 0 ;
  }
  Timer_Action_Flag[Usb_Port] = 0 ;
}




/* USER CODE END 4 */

/**
* @brief  Period elapsed callback in non blocking mode
* @note   This function is called  when TIM1 interrupt took place, inside
* HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
* a global variable "uwTick" used as application time base.
* @param  htim : TIM handle
* @retval None
*/
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  int Usb_Port=0;
  int Red_led_T;
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */
  if (PD_status[Usb_Port].Port_Status.b.CC_ATTACH_STATE != 0)
  {
    timer_cnt ++ ;
    
    if (timer_cnt == 5000)
    {
      Final_Nego_done[Usb_Port]=0;
      Timer_Action_Flag[0] = 1;
      timer_cnt = 0; 
      Core_Process_suspended =0 ;
    }
    if ( Policy_Engine_State[Usb_Port] == PE_DISABLED_STATE)
      Red_led_T = timer_cnt % 1000 ;
    else 
    {
      Red_led_T = 1;
      HAL_GPIO_WritePin(Red_LED_GPIO_Port,Red_LED_Pin,(GPIO_PinState )PD_status[Usb_Port].Port_Status.b.CC_ATTACH_STATE);// Red led is ON when port is connected 
    }
    
    if ( Red_led_T  == 0 ) // && ( Policy_Engine_State == PE_DISABLED_STATE) )
      HAL_GPIO_TogglePin(Red_LED_GPIO_Port,Red_LED_Pin);
    
  }
  else 
  {
    HAL_GPIO_WritePin(Red_LED_GPIO_Port,Red_LED_Pin,(GPIO_PinState )PD_status[Usb_Port].Port_Status.b.CC_ATTACH_STATE);
  }
  /* USER CODE END Callback 1 */
}

/**
* @brief  This function is executed in case of error occurrence.
* @retval None
*/
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
* @brief  Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  file: pointer to the source file name
* @param  line: assert_param error line source number
* @retval None
*/
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
  tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
